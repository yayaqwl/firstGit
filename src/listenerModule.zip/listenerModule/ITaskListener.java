package listenerModule;
/**
 * 任務監聽器
 * @author junezh
 *
 */
public interface ITaskListener {
	
	void onTaskFinish();

}
